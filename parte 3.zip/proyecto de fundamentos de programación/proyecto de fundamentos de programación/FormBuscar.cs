﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace proyecto_de_fundamentos_de_programación
{
    public partial class FormBuscar : Form
    {
        public FormBuscar()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            string texto_buscar = txt_buscar.Text.ToLower();
            System.Data.DataView vista_filtrada = new System.Data.DataView(Form1.tablaAlumnos);

            if (texto_buscar != "")
            {
                vista_filtrada.RowFilter = $"Nombre LIKE '%{texto_buscar}%' OR Apellido LIKE '%{texto_buscar}%'";
            }

            dgv_resultados.DataSource = vista_filtrada;
            txt_detalle_nombre.Clear();
            txt_detalle_edad.Clear();
            txt_detalle_aula.Clear();
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            Form1 menu_principal = new Form1();
            menu_principal.Show();
            this.Hide();
        }

        private void dgv_resultados_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgv_resultados.Rows[e.RowIndex];

                txt_detalle_nombre.Text = fila.Cells[0].Value.ToString() + " " + fila.Cells[1].Value.ToString();
                txt_detalle_edad.Text = fila.Cells[2].Value.ToString();
                txt_detalle_aula.Text = fila.Cells[3].Value.ToString();
                txt_detalle_apoderado.Text = fila.Cells[4].Value.ToString();
                txt_detalle_telefono.Text = fila.Cells[5].Value.ToString();
            }
        }
    }
}
