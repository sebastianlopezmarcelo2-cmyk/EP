﻿namespace proyecto_de_fundamentos_de_programación
{
    partial class FormBuscar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitule = new Label();
            lblBuscarporNombre = new Label();
            lblDetalle = new Label();
            btn_buscar = new Button();
            btn_volver = new Button();
            dgv_resultados = new DataGridView();
            Nombre = new DataGridViewTextBoxColumn();
            Apellido = new DataGridViewTextBoxColumn();
            Edad = new DataGridViewTextBoxColumn();
            Aula = new DataGridViewTextBoxColumn();
            Apoderado = new DataGridViewTextBoxColumn();
            Telefono = new DataGridViewTextBoxColumn();
            txt_buscar = new TextBox();
            txt_detalle_nombre = new TextBox();
            txt_detalle_aula = new TextBox();
            txt_detalle_edad = new TextBox();
            txt_detalle_apoderado = new TextBox();
            txt_detalle_telefono = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgv_resultados).BeginInit();
            SuspendLayout();
            // 
            // lblTitule
            // 
            lblTitule.AutoSize = true;
            lblTitule.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitule.Location = new Point(464, 23);
            lblTitule.Name = "lblTitule";
            lblTitule.Size = new Size(136, 41);
            lblTitule.TabIndex = 0;
            lblTitule.Text = "BUSCAR";
            lblTitule.Click += label1_Click;
            // 
            // lblBuscarporNombre
            // 
            lblBuscarporNombre.AutoSize = true;
            lblBuscarporNombre.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblBuscarporNombre.Location = new Point(30, 112);
            lblBuscarporNombre.Name = "lblBuscarporNombre";
            lblBuscarporNombre.Size = new Size(217, 31);
            lblBuscarporNombre.TabIndex = 1;
            lblBuscarporNombre.Text = "Buscar por Nombre:";
            // 
            // lblDetalle
            // 
            lblDetalle.AutoSize = true;
            lblDetalle.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDetalle.Location = new Point(849, 317);
            lblDetalle.Name = "lblDetalle";
            lblDetalle.Size = new Size(359, 31);
            lblDetalle.TabIndex = 2;
            lblDetalle.Text = "Detalle por Alumno Seleccionado:";
            // 
            // btn_buscar
            // 
            btn_buscar.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_buscar.Location = new Point(270, 178);
            btn_buscar.Name = "btn_buscar";
            btn_buscar.Size = new Size(148, 66);
            btn_buscar.TabIndex = 3;
            btn_buscar.Text = "Buscar";
            btn_buscar.UseVisualStyleBackColor = true;
            btn_buscar.Click += btn_buscar_Click;
            // 
            // btn_volver
            // 
            btn_volver.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_volver.Location = new Point(492, 178);
            btn_volver.Name = "btn_volver";
            btn_volver.Size = new Size(228, 66);
            btn_volver.TabIndex = 4;
            btn_volver.Text = "Volver al Menu";
            btn_volver.UseVisualStyleBackColor = true;
            btn_volver.Click += btn_volver_Click;
            // 
            // dgv_resultados
            // 
            dgv_resultados.AllowUserToAddRows = false;
            dgv_resultados.AllowUserToDeleteRows = false;
            dgv_resultados.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_resultados.Columns.AddRange(new DataGridViewColumn[] { Nombre, Apellido, Edad, Aula, Apoderado, Telefono });
            dgv_resultados.Location = new Point(12, 295);
            dgv_resultados.Name = "dgv_resultados";
            dgv_resultados.ReadOnly = true;
            dgv_resultados.RowHeadersWidth = 51;
            dgv_resultados.Size = new Size(804, 405);
            dgv_resultados.TabIndex = 5;
            dgv_resultados.CellContentClick += dgv_resultados_CellContentClick;
            // 
            // Nombre
            // 
            Nombre.HeaderText = "Nombre";
            Nombre.MinimumWidth = 6;
            Nombre.Name = "Nombre";
            Nombre.ReadOnly = true;
            Nombre.Width = 125;
            // 
            // Apellido
            // 
            Apellido.HeaderText = "Apellido";
            Apellido.MinimumWidth = 6;
            Apellido.Name = "Apellido";
            Apellido.ReadOnly = true;
            Apellido.Width = 125;
            // 
            // Edad
            // 
            Edad.HeaderText = "Edad";
            Edad.MinimumWidth = 6;
            Edad.Name = "Edad";
            Edad.ReadOnly = true;
            Edad.Width = 125;
            // 
            // Aula
            // 
            Aula.HeaderText = "Aula";
            Aula.MinimumWidth = 6;
            Aula.Name = "Aula";
            Aula.ReadOnly = true;
            Aula.Width = 125;
            // 
            // Apoderado
            // 
            Apoderado.HeaderText = "Apoderado";
            Apoderado.MinimumWidth = 6;
            Apoderado.Name = "Apoderado";
            Apoderado.ReadOnly = true;
            Apoderado.Width = 125;
            // 
            // Telefono
            // 
            Telefono.HeaderText = "Telefono";
            Telefono.MinimumWidth = 6;
            Telefono.Name = "Telefono";
            Telefono.ReadOnly = true;
            Telefono.Width = 125;
            // 
            // txt_buscar
            // 
            txt_buscar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_buscar.Location = new Point(270, 111);
            txt_buscar.Name = "txt_buscar";
            txt_buscar.Size = new Size(616, 34);
            txt_buscar.TabIndex = 6;
            // 
            // txt_detalle_nombre
            // 
            txt_detalle_nombre.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_detalle_nombre.Location = new Point(888, 369);
            txt_detalle_nombre.Name = "txt_detalle_nombre";
            txt_detalle_nombre.Size = new Size(419, 34);
            txt_detalle_nombre.TabIndex = 7;
            // 
            // txt_detalle_aula
            // 
            txt_detalle_aula.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_detalle_aula.Location = new Point(889, 493);
            txt_detalle_aula.Name = "txt_detalle_aula";
            txt_detalle_aula.Size = new Size(419, 34);
            txt_detalle_aula.TabIndex = 8;
            // 
            // txt_detalle_edad
            // 
            txt_detalle_edad.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_detalle_edad.Location = new Point(889, 429);
            txt_detalle_edad.Name = "txt_detalle_edad";
            txt_detalle_edad.Size = new Size(418, 34);
            txt_detalle_edad.TabIndex = 9;
            // 
            // txt_detalle_apoderado
            // 
            txt_detalle_apoderado.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_detalle_apoderado.Location = new Point(889, 557);
            txt_detalle_apoderado.Name = "txt_detalle_apoderado";
            txt_detalle_apoderado.Size = new Size(419, 34);
            txt_detalle_apoderado.TabIndex = 10;
            // 
            // txt_detalle_telefono
            // 
            txt_detalle_telefono.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_detalle_telefono.Location = new Point(888, 619);
            txt_detalle_telefono.Name = "txt_detalle_telefono";
            txt_detalle_telefono.Size = new Size(419, 34);
            txt_detalle_telefono.TabIndex = 11;
            // 
            // FormBuscar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1329, 733);
            Controls.Add(txt_detalle_telefono);
            Controls.Add(txt_detalle_apoderado);
            Controls.Add(txt_detalle_edad);
            Controls.Add(txt_detalle_aula);
            Controls.Add(txt_detalle_nombre);
            Controls.Add(txt_buscar);
            Controls.Add(dgv_resultados);
            Controls.Add(btn_volver);
            Controls.Add(btn_buscar);
            Controls.Add(lblDetalle);
            Controls.Add(lblBuscarporNombre);
            Controls.Add(lblTitule);
            Name = "FormBuscar";
            Text = "FormBuscar";
            ((System.ComponentModel.ISupportInitialize)dgv_resultados).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitule;
        private Label lblBuscarporNombre;
        private Label lblDetalle;
        private Button btn_buscar;
        private Button btn_volver;
        private DataGridView dgv_resultados;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Apellido;
        private DataGridViewTextBoxColumn Edad;
        private DataGridViewTextBoxColumn Aula;
        private TextBox txt_buscar;
        private TextBox txt_detalle_nombre;
        private TextBox txt_detalle_aula;
        private TextBox txt_detalle_edad;
        private DataGridViewTextBoxColumn Apoderado;
        private DataGridViewTextBoxColumn Telefono;
        private TextBox txt_detalle_apoderado;
        private TextBox txt_detalle_telefono;
    }
}