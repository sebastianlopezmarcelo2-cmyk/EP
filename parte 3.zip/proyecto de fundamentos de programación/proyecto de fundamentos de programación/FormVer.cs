﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace proyecto_de_fundamentos_de_programación
{
    public partial class FormVer : Form
    {
        public FormVer()
        {
            InitializeComponent();
        }
    }
}
