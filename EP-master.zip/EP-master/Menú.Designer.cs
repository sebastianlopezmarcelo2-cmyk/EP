﻿namespace EP
{
    partial class Menú
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            iniciarSesiónToolStripMenuItem = new ToolStripMenuItem();
            nuevoUsuarioToolStripMenuItem = new ToolStripMenuItem();
            nuevoUsuarioToolStripMenuItem1 = new ToolStripMenuItem();
            ingresarToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { iniciarSesiónToolStripMenuItem, nuevoUsuarioToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // iniciarSesiónToolStripMenuItem
            // 
            iniciarSesiónToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { nuevoUsuarioToolStripMenuItem1, ingresarToolStripMenuItem });
            iniciarSesiónToolStripMenuItem.Name = "iniciarSesiónToolStripMenuItem";
            iniciarSesiónToolStripMenuItem.Size = new Size(110, 24);
            iniciarSesiónToolStripMenuItem.Text = "Iniciar Sesión";
            // 
            // nuevoUsuarioToolStripMenuItem
            // 
            nuevoUsuarioToolStripMenuItem.Name = "nuevoUsuarioToolStripMenuItem";
            nuevoUsuarioToolStripMenuItem.Size = new Size(52, 24);
            nuevoUsuarioToolStripMenuItem.Text = "Salir";
            nuevoUsuarioToolStripMenuItem.Click += nuevoUsuarioToolStripMenuItem_Click;
            // 
            // nuevoUsuarioToolStripMenuItem1
            // 
            nuevoUsuarioToolStripMenuItem1.Name = "nuevoUsuarioToolStripMenuItem1";
            nuevoUsuarioToolStripMenuItem1.Size = new Size(224, 26);
            nuevoUsuarioToolStripMenuItem1.Text = "Nuevo Usuario";
            // 
            // ingresarToolStripMenuItem
            // 
            ingresarToolStripMenuItem.Name = "ingresarToolStripMenuItem";
            ingresarToolStripMenuItem.Size = new Size(224, 26);
            ingresarToolStripMenuItem.Text = "Ingresar";
            // 
            // Menú
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Menú";
            Text = "Menú";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem iniciarSesiónToolStripMenuItem;
        private ToolStripMenuItem nuevoUsuarioToolStripMenuItem1;
        private ToolStripMenuItem ingresarToolStripMenuItem;
        private ToolStripMenuItem nuevoUsuarioToolStripMenuItem;
    }
}