﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace proyecto_de_fundamentos_de_programación
{
    public partial class FormBuscar : Form
    {
        public FormBuscar()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            // 1. Añade estas dos líneas aquí arriba para solucionar la duplicación:
            dgvBuscar.Columns.Clear();
            dgvBuscar.AutoGenerateColumns = true;

            // 2. Tu código que ya tenías escrito y está perfecto:
            string textoBuscar = txtBuscar.Text.Trim();
            DataView vistaFiltrada = new DataView(Form1.tablaAlumnos);

            vistaFiltrada.RowFilter = $"Apellido LIKE '%{textoBuscar}%'";
            dgvBuscar.DataSource = vistaFiltrada;
        }

        private void btn_volver_Click(object sender, EventArgs e)
        {
            Form1 menu_principal = new Form1();
            menu_principal.Show();
            this.Hide();
        }

        private void FormBuscar_Load(object sender, EventArgs e)
        {

        }

        private void dgvBuscar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verificamos que el usuario haga clic en una fila con datos y no en los títulos de arriba
            if (e.RowIndex >= 0)
            {
                // Tomamos la fila completa donde el usuario hizo clic
                DataGridViewRow fila = dgvBuscar.Rows[e.RowIndex];

                // Llenamos tus 5 TextBox con los nombres de columna exactos de tu DataTable
                txt_detalle_nombre.Text = fila.Cells["Nombre"].Value.ToString();
                txt_detalle_edad.Text = fila.Cells["Edad"].Value.ToString();
                txt_detalle_aula.Text = fila.Cells["Aula"].Value.ToString();
                txt_detalle_apoderado.Text = fila.Cells["Apoderado"].Value.ToString();
                txt_detalle_telefono.Text = fila.Cells["Telefono"].Value.ToString();
            }
        }
    }
}
