﻿namespace proyecto_de_fundamentos_de_programación
{
    partial class FormOrganizar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbAulas = new ComboBox();
            dgvFiltrado = new DataGridView();
            btnVolver = new Button();
            lblTitulo = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvFiltrado).BeginInit();
            SuspendLayout();
            // 
            // cmbAulas
            // 
            cmbAulas.FormattingEnabled = true;
            cmbAulas.Location = new Point(258, 164);
            cmbAulas.Name = "cmbAulas";
            cmbAulas.Size = new Size(306, 28);
            cmbAulas.TabIndex = 0;
            cmbAulas.SelectedIndexChanged += cmbAulas_SelectedIndexChanged;
            // 
            // dgvFiltrado
            // 
            dgvFiltrado.AllowUserToAddRows = false;
            dgvFiltrado.AllowUserToDeleteRows = false;
            dgvFiltrado.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvFiltrado.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvFiltrado.Location = new Point(98, 228);
            dgvFiltrado.Name = "dgvFiltrado";
            dgvFiltrado.ReadOnly = true;
            dgvFiltrado.RowHeadersVisible = false;
            dgvFiltrado.RowHeadersWidth = 51;
            dgvFiltrado.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvFiltrado.Size = new Size(581, 188);
            dgvFiltrado.TabIndex = 1;
            // 
            // btnVolver
            // 
            btnVolver.Font = new Font("Segoe UI", 10F);
            btnVolver.Location = new Point(314, 451);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(211, 32);
            btnVolver.TabIndex = 2;
            btnVolver.Text = "Volver al Menú";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblTitulo.Location = new Point(280, 43);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(266, 28);
            lblTitulo.TabIndex = 3;
            lblTitulo.Text = "ORGANIZACIÓN DE AULAS";
            // 
            // FormOrganizar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(835, 516);
            Controls.Add(lblTitulo);
            Controls.Add(btnVolver);
            Controls.Add(dgvFiltrado);
            Controls.Add(cmbAulas);
            Name = "FormOrganizar";
            Text = "FormOrganizar";
            Load += FormOrganizar_Load;
            ((System.ComponentModel.ISupportInitialize)dgvFiltrado).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbAulas;
        private DataGridView dgvFiltrado;
        private Button btnVolver;
        private Label lblTitulo;
    }
}