namespace proyecto_de_fundamentos_de_programación
{
    public partial class Form1 : Form
    {
        public static System.Data.DataTable tablaAlumnos = new System.Data.DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void registrarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }


        void LimpiarPantalla()
        {
            txtNombre.Clear();
            txtApellido.Clear();
            txtEdad.Clear();
            txtApoderado.Clear();
            txtTelefono.Clear();
            cmbAulaRegistro.SelectedIndex = -1;
            txtNombre.Focus();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarPantalla();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            // 1. Validar que no dejen el nombre vacío
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("Por favor, ingrese el nombre del niño.", "Falta información");
                return;
            }
            // 2. Capturar los datos de la pantalla en variables de texto sencillas
            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            string edad = txtEdad.Text;
            string aula = cmbAulaRegistro.SelectedItem.ToString();
            string apoderado = txtApoderado.Text;
            string telefono = txtTelefono.Text;

            // Agregar a la tabla
            tablaAlumnos.Rows.Add(nombre, apellido, edad, aula, apoderado, telefono);

            // Guardar en el archivo de texto
            string linea_guardar = nombre + "|" + apellido + "|" + edad + "|" + aula + "|" + apoderado + "|" + telefono;
            System.IO.File.AppendAllText("alumnos_kinder.txt", linea_guardar + Environment.NewLine);

            // 4. Mostrar aviso de éxito en la pantalla
            MessageBox.Show("¡Niño registrado con éxito!", "Guardar");

            LimpiarPantalla();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult respuesta = MessageBox.Show("¿Estás seguro de salir?",
                                                          "Mensaje de confirmación",
                                                          MessageBoxButtons.YesNo,
                                                          MessageBoxIcon.Question);
            if (respuesta == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (tablaAlumnos.Columns.Count == 0)
            {
                tablaAlumnos.Columns.Add("Nombre");
                tablaAlumnos.Columns.Add("Apellido");
                tablaAlumnos.Columns.Add("Edad");
                tablaAlumnos.Columns.Add("Aula");
                tablaAlumnos.Columns.Add("Apoderado");
                tablaAlumnos.Columns.Add("Telefono");
            }

            // Deja el selector en la primera opción por defecto
            cmbAulaRegistro.SelectedIndex = 0;

            if (System.IO.File.Exists("alumnos_kinder.txt"))
            {
                string[] lineas_guardadas = System.IO.File.ReadAllLines("alumnos_kinder.txt");
                foreach (string linea in lineas_guardadas)
                {
                    string[] partes = linea.Split('|');
                    if (partes.Length == 3)
                    {
                        tablaAlumnos.Rows.Add(partes[0], partes[1], partes[2]);
                    }
                }
            }
        }
        private void buscarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormBuscar ventana_buscar = new FormBuscar();
            ventana_buscar.Show();
            this.Hide();
        }

        private void verAlumnosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVer ventana_ver = new FormVer();
            ventana_ver.Show();
            this.Hide();
        }

        private void buscarToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FormBuscar ventana_buscar = new FormBuscar();
            ventana_buscar.Show();
            this.Hide();
        }

        private void organizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOrganizar ventana_organizar = new FormOrganizar();
            ventana_organizar.Show();
            this.Hide();
        }
    }
}
