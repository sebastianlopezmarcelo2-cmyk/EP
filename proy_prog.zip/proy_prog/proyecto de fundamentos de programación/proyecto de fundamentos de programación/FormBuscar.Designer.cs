﻿namespace proyecto_de_fundamentos_de_programación
{
    partial class FormBuscar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitule = new Label();
            lblBuscarNombre_Apellido = new Label();
            lblDetalle = new Label();
            btn_buscar = new Button();
            btn_volver = new Button();
            dgvBuscar = new DataGridView();
            Nombre = new DataGridViewTextBoxColumn();
            Apellido = new DataGridViewTextBoxColumn();
            Edad = new DataGridViewTextBoxColumn();
            Aula = new DataGridViewTextBoxColumn();
            Apoderado = new DataGridViewTextBoxColumn();
            Telefono = new DataGridViewTextBoxColumn();
            txtBuscar = new TextBox();
            txt_detalle_nombre = new TextBox();
            txt_detalle_aula = new TextBox();
            txt_detalle_edad = new TextBox();
            txt_detalle_apoderado = new TextBox();
            txt_detalle_telefono = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvBuscar).BeginInit();
            SuspendLayout();
            // 
            // lblTitule
            // 
            lblTitule.AutoSize = true;
            lblTitule.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitule.Location = new Point(446, 24);
            lblTitule.Name = "lblTitule";
            lblTitule.Size = new Size(435, 41);
            lblTitule.TabIndex = 0;
            lblTitule.Text = "BÚSQUEDA DE ESTUDIANTES";
            lblTitule.Click += label1_Click;
            // 
            // lblBuscarNombre_Apellido
            // 
            lblBuscarNombre_Apellido.AutoSize = true;
            lblBuscarNombre_Apellido.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblBuscarNombre_Apellido.Location = new Point(30, 112);
            lblBuscarNombre_Apellido.Name = "lblBuscarNombre_Apellido";
            lblBuscarNombre_Apellido.Size = new Size(280, 28);
            lblBuscarNombre_Apellido.TabIndex = 1;
            lblBuscarNombre_Apellido.Text = "Buscar por Nombre y Apellido:";
            // 
            // lblDetalle
            // 
            lblDetalle.AutoSize = true;
            lblDetalle.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDetalle.Location = new Point(849, 317);
            lblDetalle.Name = "lblDetalle";
            lblDetalle.Size = new Size(359, 31);
            lblDetalle.TabIndex = 2;
            lblDetalle.Text = "Detalle por Alumno Seleccionado:";
            // 
            // btn_buscar
            // 
            btn_buscar.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_buscar.Location = new Point(160, 213);
            btn_buscar.Name = "btn_buscar";
            btn_buscar.Size = new Size(150, 42);
            btn_buscar.TabIndex = 3;
            btn_buscar.Text = "Buscar";
            btn_buscar.UseVisualStyleBackColor = true;
            btn_buscar.Click += btn_buscar_Click;
            // 
            // btn_volver
            // 
            btn_volver.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_volver.Location = new Point(536, 213);
            btn_volver.Name = "btn_volver";
            btn_volver.Size = new Size(243, 42);
            btn_volver.TabIndex = 4;
            btn_volver.Text = "Volver al Menú";
            btn_volver.UseVisualStyleBackColor = true;
            btn_volver.Click += btn_volver_Click;
            // 
            // dgvBuscar
            // 
            dgvBuscar.AllowUserToAddRows = false;
            dgvBuscar.AllowUserToDeleteRows = false;
            dgvBuscar.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvBuscar.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBuscar.Columns.AddRange(new DataGridViewColumn[] { Nombre, Apellido, Edad, Aula, Apoderado, Telefono });
            dgvBuscar.Location = new Point(12, 295);
            dgvBuscar.Name = "dgvBuscar";
            dgvBuscar.ReadOnly = true;
            dgvBuscar.RowHeadersWidth = 51;
            dgvBuscar.Size = new Size(804, 405);
            dgvBuscar.TabIndex = 5;
            dgvBuscar.CellClick += dgvBuscar_CellClick;
            // 
            // Nombre
            // 
            Nombre.HeaderText = "Nombre";
            Nombre.MinimumWidth = 6;
            Nombre.Name = "Nombre";
            Nombre.ReadOnly = true;
            // 
            // Apellido
            // 
            Apellido.HeaderText = "Apellido";
            Apellido.MinimumWidth = 6;
            Apellido.Name = "Apellido";
            Apellido.ReadOnly = true;
            // 
            // Edad
            // 
            Edad.HeaderText = "Edad";
            Edad.MinimumWidth = 6;
            Edad.Name = "Edad";
            Edad.ReadOnly = true;
            // 
            // Aula
            // 
            Aula.HeaderText = "Aula";
            Aula.MinimumWidth = 6;
            Aula.Name = "Aula";
            Aula.ReadOnly = true;
            // 
            // Apoderado
            // 
            Apoderado.HeaderText = "Apoderado";
            Apoderado.MinimumWidth = 6;
            Apoderado.Name = "Apoderado";
            Apoderado.ReadOnly = true;
            // 
            // Telefono
            // 
            Telefono.HeaderText = "Telefono";
            Telefono.MinimumWidth = 6;
            Telefono.Name = "Telefono";
            Telefono.ReadOnly = true;
            // 
            // txtBuscar
            // 
            txtBuscar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBuscar.Location = new Point(338, 109);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(616, 34);
            txtBuscar.TabIndex = 6;
            // 
            // txt_detalle_nombre
            // 
            txt_detalle_nombre.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_detalle_nombre.Location = new Point(888, 369);
            txt_detalle_nombre.Name = "txt_detalle_nombre";
            txt_detalle_nombre.Size = new Size(419, 34);
            txt_detalle_nombre.TabIndex = 7;
            // 
            // txt_detalle_aula
            // 
            txt_detalle_aula.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_detalle_aula.Location = new Point(889, 493);
            txt_detalle_aula.Name = "txt_detalle_aula";
            txt_detalle_aula.Size = new Size(419, 34);
            txt_detalle_aula.TabIndex = 8;
            // 
            // txt_detalle_edad
            // 
            txt_detalle_edad.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_detalle_edad.Location = new Point(889, 429);
            txt_detalle_edad.Name = "txt_detalle_edad";
            txt_detalle_edad.Size = new Size(418, 34);
            txt_detalle_edad.TabIndex = 9;
            // 
            // txt_detalle_apoderado
            // 
            txt_detalle_apoderado.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_detalle_apoderado.Location = new Point(889, 557);
            txt_detalle_apoderado.Name = "txt_detalle_apoderado";
            txt_detalle_apoderado.Size = new Size(419, 34);
            txt_detalle_apoderado.TabIndex = 10;
            // 
            // txt_detalle_telefono
            // 
            txt_detalle_telefono.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txt_detalle_telefono.Location = new Point(888, 619);
            txt_detalle_telefono.Name = "txt_detalle_telefono";
            txt_detalle_telefono.Size = new Size(419, 34);
            txt_detalle_telefono.TabIndex = 11;
            // 
            // FormBuscar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1329, 733);
            Controls.Add(txt_detalle_telefono);
            Controls.Add(txt_detalle_apoderado);
            Controls.Add(txt_detalle_edad);
            Controls.Add(txt_detalle_aula);
            Controls.Add(txt_detalle_nombre);
            Controls.Add(txtBuscar);
            Controls.Add(dgvBuscar);
            Controls.Add(btn_volver);
            Controls.Add(btn_buscar);
            Controls.Add(lblDetalle);
            Controls.Add(lblBuscarNombre_Apellido);
            Controls.Add(lblTitule);
            Name = "FormBuscar";
            Text = "FormBuscar";
            Load += FormBuscar_Load;
            ((System.ComponentModel.ISupportInitialize)dgvBuscar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitule;
        private Label lblBuscarNombre_Apellido;
        private Label lblDetalle;
        private Button btn_buscar;
        private Button btn_volver;
        private DataGridView dgvBuscar;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Apellido;
        private DataGridViewTextBoxColumn Edad;
        private DataGridViewTextBoxColumn Aula;
        private TextBox txtBuscar;
        private TextBox txt_detalle_nombre;
        private TextBox txt_detalle_aula;
        private TextBox txt_detalle_edad;
        private DataGridViewTextBoxColumn Apoderado;
        private DataGridViewTextBoxColumn Telefono;
        private TextBox txt_detalle_apoderado;
        private TextBox txt_detalle_telefono;
    }
}