﻿namespace proyecto_de_fundamentos_de_programación
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNombredelnino = new Label();
            lblEdad = new Label();
            lblAula = new Label();
            txtNombre = new TextBox();
            txtEdad = new TextBox();
            cmbAulaRegistro = new ComboBox();
            btnGuardar = new Button();
            btnLimpiar = new Button();
            btnSalir = new Button();
            txt_apellido = new TextBox();
            lblApellido = new Label();
            txt_telefono = new TextBox();
            lbltelefono = new Label();
            txt_apoderado = new TextBox();
            lblApoderado = new Label();
            menuStrip1 = new MenuStrip();
            verAlumnosToolStripMenuItem = new ToolStripMenuItem();
            buscarToolStripMenuItem = new ToolStripMenuItem();
            organizarToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // lblNombredelnino
            // 
            lblNombredelnino.AutoSize = true;
            lblNombredelnino.Font = new Font("Segoe UI", 10F);
            lblNombredelnino.Location = new Point(105, 71);
            lblNombredelnino.Name = "lblNombredelnino";
            lblNombredelnino.Size = new Size(144, 23);
            lblNombredelnino.TabIndex = 1;
            lblNombredelnino.Text = "Nombre del niño:";
            // 
            // lblEdad
            // 
            lblEdad.AutoSize = true;
            lblEdad.Font = new Font("Segoe UI", 10F);
            lblEdad.Location = new Point(105, 161);
            lblEdad.Name = "lblEdad";
            lblEdad.Size = new Size(52, 23);
            lblEdad.TabIndex = 2;
            lblEdad.Text = "Edad:";
            // 
            // lblAula
            // 
            lblAula.AutoSize = true;
            lblAula.Font = new Font("Segoe UI", 10F);
            lblAula.Location = new Point(105, 212);
            lblAula.Name = "lblAula";
            lblAula.Size = new Size(48, 23);
            lblAula.TabIndex = 3;
            lblAula.Text = "Aula:";
            // 
            // txtNombre
            // 
            txtNombre.Font = new Font("Segoe UI", 10F);
            txtNombre.Location = new Point(371, 68);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(295, 30);
            txtNombre.TabIndex = 4;
            // 
            // txtEdad
            // 
            txtEdad.Font = new Font("Segoe UI", 10F);
            txtEdad.Location = new Point(371, 158);
            txtEdad.Name = "txtEdad";
            txtEdad.Size = new Size(295, 30);
            txtEdad.TabIndex = 5;
            // 
            // cmbAulaRegistro
            // 
            cmbAulaRegistro.Font = new Font("Segoe UI", 10F);
            cmbAulaRegistro.FormattingEnabled = true;
            cmbAulaRegistro.Items.AddRange(new object[] { "3 años", "4 años", "5 años" });
            cmbAulaRegistro.Location = new Point(371, 209);
            cmbAulaRegistro.Name = "cmbAulaRegistro";
            cmbAulaRegistro.Size = new Size(295, 31);
            cmbAulaRegistro.TabIndex = 6;
            // 
            // btnGuardar
            // 
            btnGuardar.Font = new Font("Segoe UI", 10F);
            btnGuardar.Location = new Point(338, 381);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(124, 36);
            btnGuardar.TabIndex = 7;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Font = new Font("Segoe UI", 10F);
            btnLimpiar.Location = new Point(118, 381);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(131, 36);
            btnLimpiar.TabIndex = 8;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Font = new Font("Segoe UI", 10F);
            btnSalir.Location = new Point(563, 381);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(116, 36);
            btnSalir.TabIndex = 9;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // txt_apellido
            // 
            txt_apellido.Font = new Font("Segoe UI", 10F);
            txt_apellido.Location = new Point(371, 113);
            txt_apellido.Name = "txt_apellido";
            txt_apellido.Size = new Size(295, 30);
            txt_apellido.TabIndex = 11;
            // 
            // lblApellido
            // 
            lblApellido.AutoSize = true;
            lblApellido.Font = new Font("Segoe UI", 10F);
            lblApellido.Location = new Point(105, 116);
            lblApellido.Name = "lblApellido";
            lblApellido.Size = new Size(143, 23);
            lblApellido.TabIndex = 10;
            lblApellido.Text = "Apellido del niño:";
            // 
            // txt_telefono
            // 
            txt_telefono.Font = new Font("Segoe UI", 10F);
            txt_telefono.Location = new Point(372, 309);
            txt_telefono.Name = "txt_telefono";
            txt_telefono.Size = new Size(295, 30);
            txt_telefono.TabIndex = 13;
            // 
            // lbltelefono
            // 
            lbltelefono.AutoSize = true;
            lbltelefono.Font = new Font("Segoe UI", 10F);
            lbltelefono.Location = new Point(106, 312);
            lbltelefono.Name = "lbltelefono";
            lbltelefono.Size = new Size(78, 23);
            lbltelefono.TabIndex = 12;
            lbltelefono.Text = "Telefono:";
            // 
            // txt_apoderado
            // 
            txt_apoderado.Font = new Font("Segoe UI", 10F);
            txt_apoderado.Location = new Point(370, 261);
            txt_apoderado.Name = "txt_apoderado";
            txt_apoderado.Size = new Size(295, 30);
            txt_apoderado.TabIndex = 15;
            // 
            // lblApoderado
            // 
            lblApoderado.AutoSize = true;
            lblApoderado.Font = new Font("Segoe UI", 10F);
            lblApoderado.Location = new Point(104, 264);
            lblApoderado.Name = "lblApoderado";
            lblApoderado.Size = new Size(99, 23);
            lblApoderado.TabIndex = 14;
            lblApoderado.Text = "Apoderado:";
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { verAlumnosToolStripMenuItem, buscarToolStripMenuItem, organizarToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 16;
            menuStrip1.Text = "menuStrip1";
            // 
            // verAlumnosToolStripMenuItem
            // 
            verAlumnosToolStripMenuItem.Name = "verAlumnosToolStripMenuItem";
            verAlumnosToolStripMenuItem.Size = new Size(106, 24);
            verAlumnosToolStripMenuItem.Text = "Ver Alumnos";
            verAlumnosToolStripMenuItem.Click += verAlumnosToolStripMenuItem_Click;
            // 
            // buscarToolStripMenuItem
            // 
            buscarToolStripMenuItem.Name = "buscarToolStripMenuItem";
            buscarToolStripMenuItem.Size = new Size(66, 24);
            buscarToolStripMenuItem.Text = "Buscar";
            buscarToolStripMenuItem.Click += buscarToolStripMenuItem_Click_1;
            // 
            // organizarToolStripMenuItem
            // 
            organizarToolStripMenuItem.Name = "organizarToolStripMenuItem";
            organizarToolStripMenuItem.Size = new Size(88, 24);
            organizarToolStripMenuItem.Text = "Organizar";
            organizarToolStripMenuItem.Click += organizarToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txt_apoderado);
            Controls.Add(lblApoderado);
            Controls.Add(txt_telefono);
            Controls.Add(lbltelefono);
            Controls.Add(txt_apellido);
            Controls.Add(lblApellido);
            Controls.Add(btnSalir);
            Controls.Add(btnLimpiar);
            Controls.Add(btnGuardar);
            Controls.Add(cmbAulaRegistro);
            Controls.Add(txtEdad);
            Controls.Add(txtNombre);
            Controls.Add(lblAula);
            Controls.Add(lblEdad);
            Controls.Add(lblNombredelnino);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblNombredelnino;
        private Label lblEdad;
        private Label lblAula;
        private TextBox txtNombre;
        private TextBox txtEdad;
        private ComboBox cmbAulaRegistro;
        private Button btnGuardar;
        private Button btnLimpiar;
        private Button btnSalir;
        private TextBox txt_apellido;
        private Label lblApellido;
        private TextBox txt_telefono;
        private Label lbltelefono;
        private TextBox txt_apoderado;
        private Label lblApoderado;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem verAlumnosToolStripMenuItem;
        private ToolStripMenuItem buscarToolStripMenuItem;
        private ToolStripMenuItem organizarToolStripMenuItem;
    }
}
