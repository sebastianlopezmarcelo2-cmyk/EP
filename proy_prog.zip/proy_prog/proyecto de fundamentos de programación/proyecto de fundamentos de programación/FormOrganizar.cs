﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace proyecto_de_fundamentos_de_programación
{
    public partial class FormOrganizar : Form
    {
        public FormOrganizar()
        {
            InitializeComponent();
        }

        private void FormOrganizar_Load(object sender, EventArgs e)
        {
            // Llenamos el menú desplegable con las opciones de las aulas
            cmbAulas.Items.Add("Todos");
            cmbAulas.Items.Add("3 años");
            cmbAulas.Items.Add("4 años");
            cmbAulas.Items.Add("5 años");

            // Selecciona "Todos" por defecto al iniciar
            cmbAulas.SelectedIndex = 0;

            // Muestra todos los alumnos al principio
            dgvFiltrado.DataSource = Form1.tablaAlumnos;
        }

        private void cmbAulas_SelectedIndexChanged(object sender, EventArgs e)
        {
            string seleccion = cmbAulas.SelectedItem.ToString();
            DataView vista_filtrada = new DataView(Form1.tablaAlumnos);

            if (seleccion == "Todos")
            {
                dgvFiltrado.DataSource = Form1.tablaAlumnos;
            }
            else
            {
                // Filtramos la columna 'Aula' buscando la opción elegida (ej. "3 años")
                vista_filtrada.RowFilter = $"Aula LIKE '%{seleccion}%'";
                dgvFiltrado.DataSource = vista_filtrada;
            }
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            Form1 principal = new Form1();
            principal.Show();
            this.Close();
        }
    }
}
