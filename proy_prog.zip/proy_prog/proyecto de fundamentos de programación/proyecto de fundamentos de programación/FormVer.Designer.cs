﻿namespace proyecto_de_fundamentos_de_programación
{
    partial class FormVer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvTodos = new DataGridView();
            btnVolver = new Button();
            lblAlumnos = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvTodos).BeginInit();
            SuspendLayout();
            // 
            // dgvTodos
            // 
            dgvTodos.AllowUserToAddRows = false;
            dgvTodos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvTodos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTodos.Location = new Point(108, 248);
            dgvTodos.MultiSelect = false;
            dgvTodos.Name = "dgvTodos";
            dgvTodos.ReadOnly = true;
            dgvTodos.RowHeadersWidth = 51;
            dgvTodos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvTodos.Size = new Size(676, 188);
            dgvTodos.TabIndex = 0;
            // 
            // btnVolver
            // 
            btnVolver.Font = new Font("Segoe UI", 10F);
            btnVolver.Location = new Point(374, 495);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(190, 52);
            btnVolver.TabIndex = 1;
            btnVolver.Text = "Volver al Menú";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // lblAlumnos
            // 
            lblAlumnos.AutoSize = true;
            lblAlumnos.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            lblAlumnos.Location = new Point(289, 94);
            lblAlumnos.Name = "lblAlumnos";
            lblAlumnos.Size = new Size(359, 46);
            lblAlumnos.TabIndex = 2;
            lblAlumnos.Text = "Alumnos Registrados";
            // 
            // FormVer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(877, 606);
            Controls.Add(lblAlumnos);
            Controls.Add(btnVolver);
            Controls.Add(dgvTodos);
            Name = "FormVer";
            Text = "FormVer";
            Load += FormVer_Load;
            ((System.ComponentModel.ISupportInitialize)dgvTodos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvTodos;
        private Button btnVolver;
        private Label lblAlumnos;
    }
}