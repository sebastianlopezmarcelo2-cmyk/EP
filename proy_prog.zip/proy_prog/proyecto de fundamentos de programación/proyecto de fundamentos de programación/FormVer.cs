﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace proyecto_de_fundamentos_de_programación
{
    public partial class FormVer : Form
    {
        public FormVer()
        {
            InitializeComponent();
        }

        private void FormVer_Load(object sender, EventArgs e)
        {
            // Le decimos a la tabla de la pantalla que muestre los datos de Form1
            dgvTodos.DataSource = Form1.tablaAlumnos;
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            // Regresamos al formulario principal
            Form1 principal = new Form1();
            principal.Show();
            this.Close();
        }
    }
}
